# Buschhhhhhhhhhhh League Charter

The league charter, published as a navigable web page.

**Live:** `https://YOUR-USERNAME.github.io/REPO-NAME/`

---

## Publishing this

```bash
gh auth login      # once, if you have not already
./deploy.sh
```

That creates the repo, pushes this folder, turns on GitHub Pages, and prints
the live URL. Safe to rerun.

See `START-HERE.md` for the version with no assumed terminal knowledge, and
for how to hand the job to Claude Code instead.

---

## Amending the charter

`charter_spec.json` is the single source of truth. Every format is generated
from it. Never hand-edit the HTML or the PDFs, because the next build
overwrites them.

1. Edit `charter_spec.json`.
2. Rebuild and publish:

```bash
./update.sh "what changed"
```

That regenerates the page, both PDFs, and the preview card, then pushes.

Requires Python 3 and `reportlab` (`pip install reportlab`) for the PDF
builders. The HTML builder needs only the standard library.

### Spec structure

Each entry in `sections` has a number, an English name, a Greek label, and a
list of content blocks. Block types:

| Type | Renders as |
|---|---|
| `para` | A paragraph |
| `sub` | A small cyan caption bar |
| `bullets` | A bulleted list |
| `kv` | Config rows: label, dotted leader, value |
| `table` | A caption plus config rows |
| `note` | An amber callout, for rules with teeth |

---

## What's in here

| Path | What it is |
|---|---|
| `index.html` | The charter. One file, no dependencies, works offline. |
| `charter_spec.json` | Source of truth. Edit this. |
| `charter.md` | Plain markdown, for pasting into Sleeper or a group chat. |
| `pdf/charter-ps2.pdf` | Print/archive copy, PS2 config menu styling. |
| `pdf/charter-greek.pdf` | Print/archive copy, ancient Greek styling. |
| `card.png` | Link preview image. |
| `tools/` | The generators. |

## Using the page

- Click a category, or use the arrow keys.
- Press `/` to search the full text of every section.
- On a phone, swipe left or right to change sections.
- Every section has its own link. Copy the address bar to send someone a
  specific rule, for example `#trades` or `#toilet-bowl`.
- Print, or save as PDF from the browser, to get all sections as one plain
  black-on-white document.

## Open questions

Not yet settled, and not represented in the spec:

- **Taxi squad deadline.** Sleeper offers "no deadline" or "first week of
  preseason." The league has not recorded which is set.
- **Playoff draft slot tiebreak.** Slots 1 through 6 go by how far a team got
  in the playoffs, but two teams lose in each round. Seed order is the
  obvious tiebreak; it is not written down.
